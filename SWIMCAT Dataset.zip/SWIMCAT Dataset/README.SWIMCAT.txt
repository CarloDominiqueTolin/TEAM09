The SWIMCAT dataset contains 784 images of sky/cloud patches, categorized in 5 distinct categories: clear sky, patterned clouds, thick dark clouds, thick white clouds, and veil clouds. All images were captured in Singapore using WAHRSIS, a calibrated ground-based whole sky imager, over a period of 17 months from January 2013 to May 2014. The patches have a dimension of 125x125 pixels.

More details about the dataset can be found in the following paper:
S. Dev, Y. H. Lee, S. Winkler.
Categorization of cloud image patches using an improved texton-based approach.
Proc. IEEE International Conference on Image Processing (ICIP), Québec City, Canada, Sep. 27-30, 2015.


This folder contains the following:
- A Clear Sky 
- B Patterned Clouds
- C Thick Dark Clouds
- D Thick White Clouds
- E Veil Clouds

Link: https://vintage.winklerbros.net/swimcat.html